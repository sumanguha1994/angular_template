import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuard } from './guards/admin.guard';
import { GuestGuard } from './guards/guest.guard';
import { LoginComponent } from './pages/auth/login/login.component';
import { P404Component } from './pages/errors/404.component';
import { DefaultLayoutComponent } from './pages/layouts/default-layout/default-layout.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    canActivate: [GuestGuard],
    data: { pageTitle: 'Login' },
  },

  {
    path: '',
    component: DefaultLayoutComponent,
    canActivate: [AdminGuard],
    children: [
      {
        path: '',
        loadChildren: () => import('./pages/dashboard/dashboard.module').then(m => m.DashboardModule)
      },
    ]
  },

  { path: '**', component: P404Component, data: { pageTitle: 'Not Found' } }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
