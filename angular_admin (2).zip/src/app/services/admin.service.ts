import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(
    private httpService: HttpService
  ) { }

  /** 
   * ADMIN PROFILE APIs 
   * -----------------------
   * */

  updateAdminProfile(payload: any) {
    return this.httpService.post('admin/profile/update', payload);
  }

  /** 
   * MEMBER MANAGEMENT APIs 
   * ------------------------
   * */

  fetchMembers(payload: any) {
    return this.httpService.post('admin/members/view', payload);
  }

  createMember(payload: any) {
    return this.httpService.post('admin/members/add', payload);
  }

  updateMember(payload: any) {
    return this.httpService.postFormData('admin/members/edit', payload);
  }

  changeMemberStatus(payload: any) {
    return this.httpService.post('admin/members/change-status', payload);
  }

  generateMemberRegeLink(payload: any) {
    return this.httpService.post('admin/members/create-registration-link', payload);
  }

  fetchMemberMaster(payload: any = {}) {
    return this.httpService.post('admin/members/fetch-master', payload);
  }

  /** 
   * PROJECT MANAGEMENT APIs 
   * ------------------------
   * */

  fetchProjects(payload: any = {}) {
    return this.httpService.post('admin/projects/view', payload);
  }

  createProject(payload: any) {
    return this.httpService.postFormData('admin/projects/add', payload);
  }

  updateProject(payload: any) {
    return this.httpService.postFormData('admin/projects/edit', payload);
  }

  changeProjectStatus(payload: any) {
    return this.httpService.post('admin/projects/change-status', payload);
  }

  deleteProject(payload: any) {
    return this.httpService.post('admin/projects/delete', payload);
  }

  fetchProjectDetails(payload: any) {
    return this.httpService.post('admin/projects/details', payload);
  }

  /** 
   * PROJECT TASKS MANAGEMENT APIs 
   * ------------------------------
   * */

  fetchProjectTasks(payload: any = {}) {
    return this.httpService.post('admin/project/task/view', payload);
  }

  createProjectTask(payload: any) {
    return this.httpService.postFormData('admin/project/task/add', payload);
  }

  updateProjectTask(payload: any) {
    return this.httpService.postFormData('admin/project/task/edit', payload);
  }

  changeProjectTaskStatus(payload: any) {
    return this.httpService.post('admin/project/task/change-status', payload);
  }

  deleteProjectTask(payload: any) {
    return this.httpService.post('admin/project/task/delete', payload);
  }

  fetchProjectTaskDetails(payload: any) {
    return this.httpService.post('admin/project/task/details', payload);
  }

  /** 
   * PROJECT CHANNELS MANAGEMENT APIs 
   * --------------------------------
   * */

  fetchProjectChannels(payload: any = {}) {
    return this.httpService.post('admin/project/channel/view', payload);
  }

  fetchUserAssignesForProjectChannel(payload: any) {
    return this.httpService.post('admin/project/channel/fetch-assignes', payload);
  }

  assignUserToProjectChannel(payload: any) {
    return this.httpService.post('admin/project/channel/assign-user', payload);
  }
  
  removeUserFromProjectChannel(payload: any) {
    return this.httpService.post('admin/project/channel/remove-user', payload);
  }

  fetchProjectChannelUsers(payload: any = {}) {
    return this.httpService.post('admin/project/channel/users', payload);
  }

  /** 
   * PROJECT TASKS USERS MNGMNT APIs 
   * -------------------------------
   * */

  fetchProjectTaskUsers(payload: any) {
    return this.httpService.post('admin/project/task/user/view', payload);
  }

  assignUserToTask(payload: any) {
    return this.httpService.post('admin/project/task/user/assign', payload);
  }

  removeUserFromTask(payload: any) {
    return this.httpService.post('admin/project/task/user/remove', payload);
  }

  fetchUserAssignesForTask(payload: any) {
    return this.httpService.post('admin/project/task/user/fetch-assignes', payload);
  }

  updateUserTaskStatus(payload: any) {
    return this.httpService.post('admin/project/task/user/change-status', payload);
  }

  /** 
   * MASTER MANAGEMENT APIs 
   * ------------------------
   * */

  fetchDeparments(payload: any = {}) {
    return this.httpService.post('admin/masters/department/view', payload);
  }

  createDepartment(payload: any) {
    return this.httpService.post('admin/masters/department/add', payload);
  }

  updateDepartment(payload: any) {
    return this.httpService.post('admin/masters/department/edit', payload);
  }

  changeDepartmentStatus(payload: any) {
    return this.httpService.post('admin/masters/department/change-status', payload);
  }

  deleteDepartment(payload: any) {
    return this.httpService.post('admin/masters/department/delete', payload);
  }

  fetchDivisions(payload: any = {}) {
    return this.httpService.post('admin/masters/division/view', payload);
  }

  createDivision(payload: any) {
    return this.httpService.post('admin/masters/division/add', payload);
  }

  updateDivision(payload: any) {
    return this.httpService.post('admin/masters/division/edit', payload);
  }

  changeDivisionStatus(payload: any) {
    return this.httpService.post('admin/masters/division/change-status', payload);
  }

  deleteDivision(payload: any) {
    return this.httpService.post('admin/masters/division/delete', payload);
  }
}
