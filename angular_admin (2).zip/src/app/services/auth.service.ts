import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(
    private httpService: HttpService,
    private router: Router
  ) { }

  /**
   * ====================================================
   * Admin Authentication Methods
   *
   * Token Name - admin-template-token
   * User Details - admin-template-user
   * ====================================================
   * */

  adminLogin(payload: any) {
    return this.httpService.post('auth/admin/login', payload);
  }

  adminLogout() {
    localStorage.removeItem('admin-template-token');
    localStorage.removeItem('admin-template-user');
    this.router.navigate(['/login'])
  }

  adminLoggedIn() {
    return !!localStorage.getItem('admin-template-token')
  }

  getAdminToken() {
    return localStorage.getItem('admin-template-token')
  }

  getAdminAccountDetails() {
    return this.httpService.post('auth/admin/getaccount', {});
  }

  /**
   * =====================================================
   * End of Admin Authentication Methods
   * =====================================================
   * */

  getToken() {
    if (this.getAdminToken()) {
      return localStorage.getItem('admin-template-token')
    } else {
      return null;
    }
  }
}
