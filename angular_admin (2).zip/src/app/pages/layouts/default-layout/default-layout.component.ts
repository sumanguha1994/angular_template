import { Component, Injectable, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { navItems } from '../_nav';

@Injectable()

@Component({
  selector: 'app-dashboard',
  templateUrl: './default-layout.component.html'
})
export class DefaultLayoutComponent implements OnInit {
  public sidebarMinimized = false;
  public navItems = navItems;

  PageTitle: any;
  PageBreadcrumb: any;

  constructor(
    public authService: AuthService,
    private router: Router,
  ) {
    setTimeout(() => {
      this.initPageIndentifier()
    })
  }

  ngOnInit() {
    this.router.events.subscribe(event => {
      // if (event instanceof NavigationStart) {
      // }

      if (event instanceof NavigationEnd) {
        this.initPageIndentifier();
      }
    });
  }

  initPageIndentifier() {
    this.PageTitle = `<i class="icon-graph"></i>&nbsp;Control Panel`;
    this.PageBreadcrumb = null;
  }

  toggleMinimize(e: any) {
    this.sidebarMinimized = e;
  }
}
