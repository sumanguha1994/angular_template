import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/home',
    icon: 'icon-speedometer',
  },
  {
    name: 'Members',
    url: '/members',
    icon: 'icon-user',
    children: [
      {
        name: 'Managers',
        url: '/members/manager',
        icon: 'icon-user'
      },
      {
        name: 'Employees',
        url: '/members/employee',
        icon: 'icon-user'
      },
      {
        name: 'Contractors',
        url: '/members/contractor',
        icon: 'icon-user'
      },
      {
        name: 'Suppliers',
        url: '/members/supplier',
        icon: 'icon-user'
      },
      {
        name: 'Safety Managers',
        url: '/members/safety-manager',
        icon: 'icon-user'
      },
    ]
  },
  {
    name: 'Projects',
    url: '/projects',
    icon: 'cil-apps',
  },
  {
    name: 'Masters',
    url: '/master',
    icon: 'icon-settings',
    children: [
      {
        name: 'Departments',
        url: '/master/departments',
        icon: 'icon-settings'
      },
      {
        name: 'Divisions',
        url: '/master/divisions',
        icon: 'icon-settings'
      },
    ]
  },
];
