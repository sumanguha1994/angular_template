import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as Global from 'src/app/global';
import PaginationOptions from 'src/app/models/PaginationOptions';
import { AdminService } from 'src/app/services/admin.service';
import swal from 'sweetalert2';

@Component({
    selector: 'app-media-uploader',
    templateUrl: './media-uploader.component.html'
})
export class ProjectsComponent implements OnInit {
    Global = Global;
    projectForm: FormGroup;
    paginationOptions: PaginationOptions;
    departments: any[] = [];
    editActionId: any = null;

    constructor(
        private formBuilder: FormBuilder,
        private adminService: AdminService,
        private toastr: ToastrService,
        private spinner: NgxSpinnerService,
    ) {
        this.projectForm = formBuilder.group({
            name: [null, Validators.compose([Validators.required])],
            location: [null, Validators.compose([Validators.required])],
        });

        this.paginationOptions = Global.resetPaginationOption();
    }

    async ngOnInit() {

    }

    dropped(event: any) {
        console.log(event)
    }
    fileOver(event: any) {
        console.log(event)
    }
    fileLeave(event: any) {
        console.log(event)
    }
}
