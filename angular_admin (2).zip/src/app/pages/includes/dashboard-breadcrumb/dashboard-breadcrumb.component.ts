import { Component, Input, OnInit, ViewChild } from '@angular/core';
import * as Global from 'src/app/global';

@Component({
    selector: 'app-dashboard-breadcrumb',
    templateUrl: './dashboard-breadcrumb.component.html'
})
export class DashboardBreadcrumbComponent implements OnInit {
    Global = Global;

    @Input() PageBreadcrumb: any;
    @Input() PageTitle: any;

    constructor() { }

    ngOnInit(): void {
        this.PageTitle = null;
        this.PageBreadcrumb = null;
    }
}
