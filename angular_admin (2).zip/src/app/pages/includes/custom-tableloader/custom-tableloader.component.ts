import { Component, Injectable } from '@angular/core';

@Injectable()

@Component({
  selector: 'custom-tableloader',
  templateUrl: './custom-tableloader.component.html',
})
export class CustomTableLoaderComponent {
  show({
    id = <string>""
  } = {}) {
    let loaderElement: any = null;
    if (id)
      loaderElement = document.getElementById(id)?.querySelector('#table-processing');
    else
      loaderElement = document.getElementById('table-processing');


    if (loaderElement) {
      loaderElement.style.display = 'block';
    }
  }

  hide({
    id = <any>null
  } = {}) {
    let loaderElement: any = null;
    if (id)
      loaderElement = document.getElementById(id)?.querySelector('#table-processing');
    else
      loaderElement = document.getElementById('table-processing');


    if (loaderElement) {
      loaderElement.style.display = 'none';
    }
  }
}
