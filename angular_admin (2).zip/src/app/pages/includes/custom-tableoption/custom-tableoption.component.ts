import { Component, Injectable, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Injectable()

@Component({
  selector: 'custom-tableoption',
  templateUrl: './custom-tableoption.component.html',
})
export class CustomTableOptionComponent {
  filterForm: FormGroup;

  @Output() onFilterChanged: EventEmitter<any> = new EventEmitter<any>();

  constructor(
    private formBuilder: FormBuilder,
  ) {
    this.filterForm = formBuilder.group({
      searchkey: [null],      
    });
  }

}
