import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import * as Global from 'src/app/global';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {
  Global = Global;
  loginForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private toastr: ToastrService,
    private router: Router,
  ) {
    this.loginForm = formBuilder.group({
      email: ['admin.ivan@yopmail.com', Validators.compose([Validators.required, Validators.email])],
      password: ['qwer1234', Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(20)])],
    });
  }

  ngOnInit(): void {
  }

  login(event: any) {
    this.loginForm.markAllAsTouched();
    Global.scrollToQuery(".form-control.is-invalid");

    if (this.loginForm.valid) {
      event.target.classList.add('btn-loading');
      event.target.disabled = true;

      this.authService.adminLogin({
        'email': this.loginForm.value.email,
        'password': this.loginForm.value.password,
      }).subscribe(res => {
        const data = res.data;
        if (res.status == 'success') {
          this.toastr.success(res.message);
          localStorage.setItem('admin-template-token', data.token);
          localStorage.setItem('admin-template-user', JSON.stringify(data.user));
          this.router.navigate(['/home']);
          return;
        } else if (res.status == 'val_error') {
          this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
        } else {
          this.toastr.error(res.message);
        }

        event.target.classList.remove('btn-loading');
        event.target.disabled = false;
      }, (err) => {
        event.target.classList.remove('btn-loading');
        event.target.disabled = false;
        this.toastr.error(Global.getServerErrorMessage(err));
      });
    }
  }
}
