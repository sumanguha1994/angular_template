import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { AppComponent } from 'src/app/app.component';
import * as Global from 'src/app/global';
import PaginationOptions from 'src/app/models/PaginationOptions';
import { AdminService } from 'src/app/services/admin.service';
import { AuthService } from 'src/app/services/auth.service';
import { CustomTableLoaderComponent } from '../../includes/custom-tableloader/custom-tableloader.component';
import { ModalDirective } from 'ngx-bootstrap/modal';
import swal from 'sweetalert2';
import { DefaultLayoutComponent } from '../../layouts/default-layout/default-layout.component';
import TableFilterOptions from 'src/app/models/TableFiilterOptions';

@Component({
    selector: 'app-members',
    templateUrl: './members.component.html'
})
export class MembersComponent implements OnInit {
    Global = Global;
    memberForm: FormGroup;
    memberPasswordForm: FormGroup;
    memberProfilePicForm: FormGroup;
    regLinkGenForm: FormGroup;
    paginationOptions: PaginationOptions;
    members: any[] = [];
    departmentMaster: any[] = [];
    divisionMaster: any[] = [];
    editActionId: any = null;

    @ViewChild('changePwdModal') public changePwdModal: ModalDirective;
    @ViewChild('changeProfilePicModal') public changeProfilePicModal: ModalDirective;
    @ViewChild('regLinkGenModal') public regLinkGenModal: ModalDirective;

    MemberType = {
        'slug': "",
        'name': "",
    }

    constructor(
        private formBuilder: FormBuilder,
        private adminService: AdminService,
        private authService: AuthService,
        private toastr: ToastrService,
        private spinner: NgxSpinnerService,
        private activatedRoute: ActivatedRoute,
        private appComponent: AppComponent,
        private tableLoader: CustomTableLoaderComponent,
        private defaultLayout: DefaultLayoutComponent
    ) {
        this.memberForm = formBuilder.group({
            name: [null, Validators.compose([Validators.required])],
            email: [null, Validators.compose([Validators.required, Validators.email])],
            mobile: [null, Validators.compose([Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)])],
            department_id: [null, Validators.compose([Validators.required])],
            division_id: [null, Validators.compose([Validators.required])],
        });

        this.memberPasswordForm = formBuilder.group({
            user_id: [null, Validators.compose([Validators.required])],
            password: [null, Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(20)])],
            password_confirmation: [null, Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(20)])],
            user_details: [null],
        });

        this.memberProfilePicForm = formBuilder.group({
            user_id: [null, Validators.compose([Validators.required])],
            image: [null, Validators.compose([Validators.required])],
            image_source: [null, Validators.compose([Validators.required])],
            user_details: [null],
        });

        this.regLinkGenForm = formBuilder.group({
            name: [null, Validators.compose([Validators.required])],
            email: [null, Validators.compose([Validators.required, Validators.email])],
            mobile: [null, Validators.compose([Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)])],
            department_id: [null, Validators.compose([Validators.required])],
            division_id: [null, Validators.compose([Validators.required])],
        });

        const rt = this.appComponent.getActivatedRouteChild(this.activatedRoute);
        rt.data.subscribe((data: any) => {
            if (data.MemberType) {
                this.MemberType = data.MemberType
            } else {
                this.toastr.error("MEMBER SLUG NOT ADDED IN APP.ROUTING.MODULE.TS");
            }
        });

        this.paginationOptions = Global.resetPaginationOption();
    }

    async ngOnInit() {
        setTimeout(() => {
            this.defaultLayout.PageTitle = `<i class="icon-user"></i>&nbsp;${this.MemberType.name}s`
            this.defaultLayout.PageBreadcrumb = [
                { 'url': null, 'active': false, 'name': `Members` },
                { 'url': null, 'active': true, 'name': `${this.MemberType.name}s` },
            ]

            this.fetchMembers()
        });

        await this.fetchMermbersMaster();
    }

    fetchMermbersMaster() {
        return new Promise((resolve, reject) => {
            this.spinner.show()
            this.departmentMaster = [];
            this.divisionMaster = [];
            this.adminService.fetchMemberMaster().subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.departmentMaster = data.departments
                    this.divisionMaster = data.divisions
                } else {
                    this.toastr.error(res.message);
                }

                this.spinner.hide();
                resolve(true);
            }, (err) => {
                this.spinner.hide();
                this.toastr.error(Global.getServerErrorMessage(err));
                resolve(true);
            });
        })
    }

    cancelEntry() {
        this.editActionId = null;
        Global.resetForm(this.memberForm);
        Global.scrollToQuery('#member-submit-section');
    }

    getEdit(item: any) {
        this.editActionId = item._id;
        this.memberForm.patchValue({
            'name': item?.name ?? null,
            'email': item?.email ?? null,
            'mobile': item?.mobile ?? null,
            'department_id': item?.department_id ?? null,
            'division_id': item?.division_id ?? null,
        })

        Global.scrollToQuery('#member-submit-section');
    }

    fetchMembers(page: any = null, options: TableFilterOptions = Global.resetTableFilterOptions()) {
        if (page != null) {
            this.paginationOptions.page = page;
        }

        this.tableLoader.show();
        this.adminService.fetchMembers({
            'role': this.MemberType.slug,
            'pageno': this.paginationOptions.page,
            'searchkey': options.searchkey,
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.members = data.users?.docs ?? [];
                this.paginationOptions = {
                    hasNextPage: data.users.hasNextPage,
                    hasPrevPage: data.users.hasPrevPage,
                    limit: data.users.limit,
                    nextPage: data.users.nextPage,
                    page: data.users.page,
                    pagingCounter: data.users.pagingCounter,
                    prevPage: data.users.prevPage,
                    totalDocs: data.users.totalDocs,
                    totalPages: data.users.totalPages,
                };
            } else {
                this.toastr.error(res.message);

                this.members = [];
                this.paginationOptions = Global.resetPaginationOption();
            }

            this.tableLoader.hide();
        }, (err) => {
            this.members = [];
            this.tableLoader.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
            this.paginationOptions = Global.resetPaginationOption();
        });
    }

    addMember(event: any) {
        this.memberForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.memberForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.createMember({
                'role': this.MemberType.slug,
                'name': this.memberForm.value.name,
                'email': this.memberForm.value.email,
                'mobile': this.memberForm.value.mobile,
                'department_id': this.memberForm.value.department_id,
                'division_id': this.memberForm.value.division_id,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    swal.fire({
                        // title: `Member Created`,
                        html: `<h4 class="text-uppercase text-primary">Login Credentials</h4>\
                                <p class="mb-1">Email: <b>${data.logincredentials.email}</b></p>\
                                <p class="mb-1">Password: <b>${data.logincredentials.password}</b></p>`,
                        icon: 'success',
                        confirmButtonText: 'OKAY',
                    });

                    this.toastr.success(res.message);
                    this.cancelEntry();
                    this.fetchMembers();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    editMember(event: any) {
        this.memberForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.memberForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.updateMember({
                'user_id': this.editActionId,
                'operation': 'basicdetails',
                'name': this.memberForm.value.name,
                'email': this.memberForm.value.email,
                'mobile': this.memberForm.value.mobile,
                'department_id': this.memberForm.value.department_id,
                'division_id': this.memberForm.value.division_id,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.fetchMembers();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    changeMemberStatus(item: any) {
        this.spinner.show();
        this.adminService.changeMemberStatus({
            'user_id': item._id,
            'status': (item.status == 'active') ? 'inactive' : 'active',
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.fetchMembers();
                this.toastr.success(res.message);
            } else {
                this.toastr.error(res.message);
            }

            this.spinner.hide();
        }, (err) => {
            this.spinner.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
        });
    }

    /**
     * ================================
     * MEMBER PASSWORD CHANGE FUNCTIONS
     * ================================
     * ================================
     */

    initMemberChangePwd(item: any) {
        this.memberPasswordForm.patchValue({
            'user_id': item._id,
            'user_details': item,
        })

        this.changePwdModal.show();
    }

    changeMemberPwd(event: any) {
        this.memberPasswordForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.memberPasswordForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.updateMember({
                'operation': "password",
                'user_id': this.memberPasswordForm.value.user_id,
                'password': this.memberPasswordForm.value.password,
                'password_confirmation': this.memberPasswordForm.value.password_confirmation,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.cancelMemberPwdUpdate();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    cancelMemberPwdUpdate() {
        Global.resetForm(this.memberPasswordForm)
        this.changePwdModal.hide();
    }

    /**
     * =======================================
     *  REGISTRATION LINK GENERATION FUNCTIONS
     * =======================================
     * =======================================
     */

    initMemberRegLinkGeneration() {
        Global.resetForm(this.regLinkGenForm)
        this.regLinkGenModal.show();
    }

    generateRegLink(event: any) {
        this.regLinkGenForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.regLinkGenForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.generateMemberRegeLink({
                'role': this.MemberType.slug,
                'name': this.regLinkGenForm.value.name,
                'email': this.regLinkGenForm.value.email,
                'mobile': this.regLinkGenForm.value.mobile,
                'department_id': this.regLinkGenForm.value.department_id,
                'division_id': this.regLinkGenForm.value.division_id,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    swal.fire({
                        title: "Success Message",
                        html: `<p><span>Registration link has been sent successfully</span>\
                        <br><a target=_blank href="${res.data.registration_link}">Visit Link</a>\
                        </p>`,
                        icon: 'success',
                        confirmButtonText: 'OKAY',
                    })

                    // this.toastr.success(res.message);
                    Global.resetForm(this.regLinkGenForm)
                    this.regLinkGenModal.hide();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    /**
     * =================================
     * PROFILE PICTURE CHANGE FUNCTIONS
     * =================================
     * =================================
     */

    initMemberChangeProfilePic(item: any) {
        this.memberProfilePicForm.patchValue({
            'user_id': item._id,
            'user_details': item,
        })

        this.changeProfilePicModal.show();
    }

    changeMemberProfilePic(event: any) {
        this.memberProfilePicForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.memberProfilePicForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.updateMember({
                'operation': "profilepicture",
                'user_id': this.memberProfilePicForm.value.user_id,
                'image': this.memberProfilePicForm.value.image_source ?? "",
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.cancelMemberProfilePicUpdate();
                    this.fetchMembers();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    cancelMemberProfilePicUpdate() {
        Global.resetForm(this.memberProfilePicForm)
        this.changeProfilePicModal.hide();
    }
}
