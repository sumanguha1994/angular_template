import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { ChartsModule } from 'ng2-charts';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxFileDropModule } from 'ngx-file-drop';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { CustomPaginationComponent } from '../includes/custom-pagination/custom-pagination.component';
import { CustomTableLoaderComponent } from '../includes/custom-tableloader/custom-tableloader.component';
import { CustomTableOptionComponent } from '../includes/custom-tableoption/custom-tableoption.component';
// import { DashboardBreadcrumbComponent } from '../includes/dashboard-breadcrumb/dashboard-breadcrumb.component';

import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { MembersComponent } from './members/members.component';
import { DepartmentMasterComponent } from './masters/departments.component';
import { DivisionMasterComponent } from './masters/divisions.component';
import { ProjectsComponent } from './projects/projects.component';
import { ProjectViewComponent } from './projects/project-view.component';
import { ProjectTaskViewComponent } from './projects/project-task-view.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        DashboardRoutingModule,
        ChartsModule,
        FormsModule,
        ReactiveFormsModule,
        TooltipModule.forRoot(),
        ModalModule.forRoot(),
        NgSelectModule,
        NgxFileDropModule,
        TabsModule,
        BsDatepickerModule.forRoot(),
    ],
    declarations: [
        CustomPaginationComponent,
        CustomTableLoaderComponent,
        CustomTableOptionComponent,
        // DashboardBreadcrumbComponent,
        HomeComponent,
        ProfileComponent,
        MembersComponent,
        DepartmentMasterComponent,
        DivisionMasterComponent,
        ProjectsComponent,
        ProjectViewComponent,
        ProjectTaskViewComponent
    ],
    providers: [
        CustomTableLoaderComponent

    ],
})
export class DashboardModule { }