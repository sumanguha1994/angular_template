import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { DepartmentMasterComponent } from './masters/departments.component';
import { DivisionMasterComponent } from './masters/divisions.component';
import { MembersComponent } from './members/members.component';
import { ProfileComponent } from './profile/profile.component';
import { ProjectTaskViewComponent } from './projects/project-task-view.component';
import { ProjectViewComponent } from './projects/project-view.component';
import { ProjectsComponent } from './projects/projects.component';

const routes: Routes = [
    {
        path: '',
        data: { pageTitle: 'Dashboard' },
        children: [
            { path: '', redirectTo: 'home' },
            { path: 'home', component: HomeComponent, data: { pageTitle: 'Home' } },
            { path: 'profile', component: ProfileComponent, data: { pageTitle: 'Profile' } },

            { path: 'members/manager', component: MembersComponent, data: { pageTitle: 'Managers', MemberType: { slug: "manager", name: "Manager" } } },
            { path: 'members/employee', component: MembersComponent, data: { pageTitle: 'Employees', MemberType: { slug: "employee", name: "Employee" } } },
            { path: 'members/contractor', component: MembersComponent, data: { pageTitle: 'Contractors', MemberType: { slug: "contractor", name: "Contractor" } } },
            { path: 'members/supplier', component: MembersComponent, data: { pageTitle: 'Suppliers', MemberType: { slug: "supplier", name: "Supplier" } } },
            { path: 'members/safety-manager', component: MembersComponent, data: { pageTitle: 'Safety Managers', MemberType: { slug: "safety_manager", name: "Safety Manager" } } },

            { path: 'projects', component: ProjectsComponent, data: { pageTitle: 'Projects', } },
            { path: 'projects/:project_id/view', component: ProjectViewComponent, data: { pageTitle: 'Projects', } },
            { path: 'projects/task/:task_id/view', component: ProjectTaskViewComponent, data: { pageTitle: 'Projects', } },

            { path: 'master/departments', component: DepartmentMasterComponent, data: { pageTitle: 'Departments', } },
            { path: 'master/divisions', component: DivisionMasterComponent, data: { pageTitle: 'Divisions', } },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class DashboardRoutingModule { }
