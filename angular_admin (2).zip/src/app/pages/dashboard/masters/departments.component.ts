import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as Global from 'src/app/global';
import PaginationOptions from 'src/app/models/PaginationOptions';
import { AdminService } from 'src/app/services/admin.service';
import { CustomTableLoaderComponent } from '../../includes/custom-tableloader/custom-tableloader.component';
import swal from 'sweetalert2';
import { DefaultLayoutComponent } from '../../layouts/default-layout/default-layout.component';
import TableFilterOptions from 'src/app/models/TableFiilterOptions';

@Component({
    selector: 'app-master-departments',
    templateUrl: './departments.component.html'
})
export class DepartmentMasterComponent implements OnInit {
    Global = Global;
    departmentForm: FormGroup;
    paginationOptions: PaginationOptions;
    departments: any[] = [];
    editActionId: any = null;

    constructor(
        private formBuilder: FormBuilder,
        private adminService: AdminService,
        private toastr: ToastrService,
        private spinner: NgxSpinnerService,
        private tableLoader: CustomTableLoaderComponent,
        private defaultLayout: DefaultLayoutComponent
    ) {
        this.departmentForm = formBuilder.group({
            name: [null, Validators.compose([Validators.required])],
        });

        this.paginationOptions = Global.resetPaginationOption();
    }

    async ngOnInit() {
        setTimeout(() => {
            this.defaultLayout.PageTitle = `<i class="icon-settings"></i>&nbsp;Departments`
            this.defaultLayout.PageBreadcrumb = [
                { 'url': null, 'active': false, 'name': `Masters` },
                { 'url': null, 'active': true, 'name': `Departments` },
            ]

            this.fetchDeparments()
        });
    }

    cancelEntry() {
        this.editActionId = null;
        Global.resetForm(this.departmentForm);
        Global.scrollToQuery('#department-submit-section');
    }

    getEdit(item: any) {
        this.cancelEntry();
        this.editActionId = item._id;
        this.departmentForm.patchValue({
            'name': item?.name ?? null,
        })
    }

    fetchDeparments(page: any = null, options: TableFilterOptions = Global.resetTableFilterOptions()) {
        if (page != null) {
            this.paginationOptions.page = page;
        }

        this.tableLoader.show();
        this.adminService.fetchDeparments({
            'pageno': this.paginationOptions.page,
            'searchkey': options.searchkey,
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.departments = data.departments?.docs ?? [];
                this.paginationOptions = {
                    hasNextPage: data.departments.hasNextPage,
                    hasPrevPage: data.departments.hasPrevPage,
                    limit: data.departments.limit,
                    nextPage: data.departments.nextPage,
                    page: data.departments.page,
                    pagingCounter: data.departments.pagingCounter,
                    prevPage: data.departments.prevPage,
                    totalDocs: data.departments.totalDocs,
                    totalPages: data.departments.totalPages,
                };
            } else {
                this.toastr.error(res.message);

                this.departments = [];
                this.paginationOptions = Global.resetPaginationOption();
            }

            this.tableLoader.hide();
        }, (err) => {
            this.departments = [];
            this.tableLoader.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
            this.paginationOptions = Global.resetPaginationOption();
        });
    }

    addDepartment(event: any) {
        this.departmentForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.departmentForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.createDepartment({
                'name': this.departmentForm.value.name,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.cancelEntry();
                    this.fetchDeparments();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    editDepartment(event: any) {
        this.departmentForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.departmentForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.updateDepartment({
                'department_id': this.editActionId,
                'name': this.departmentForm.value.name,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.fetchDeparments();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    changeDepartmentStatus(item: any) {
        this.spinner.show();
        this.adminService.changeDepartmentStatus({
            'department_id': item._id,
            'status': (item.status == 'active') ? 'inactive' : 'active',
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.fetchDeparments();
                this.toastr.success(res.message);
            } else {
                this.toastr.error(res.message);
            }

            this.spinner.hide();
        }, (err) => {
            this.spinner.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
        });
    }

    deleteDepartment(item: any) {
        swal.fire({
            title: 'Are you sure want to remove?',
            text: 'You will not be able to recover this data!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, keep it'
        }).then((result) => {
            if (result.value) {
                this.spinner.show();
                this.adminService.deleteDepartment({
                    'department_id': item._id,
                }).subscribe(res => {
                    const data = res.data;
                    if (res.status == 'success') {
                        this.fetchDeparments();
                        this.toastr.success(res.message);
                    } else {
                        this.toastr.error(res.message);
                    }

                    this.spinner.hide();
                }, (err) => {
                    this.spinner.hide();
                    this.toastr.error(Global.getServerErrorMessage(err));
                });
            } else if (result.dismiss === swal.DismissReason.cancel) {
                swal.fire(
                    'Cancelled',
                    'Your data is safe :)',
                    'error'
                )
            }
        })
    }
}
