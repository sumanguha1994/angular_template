import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as Global from 'src/app/global';
import PaginationOptions from 'src/app/models/PaginationOptions';
import { AdminService } from 'src/app/services/admin.service';
import { CustomTableLoaderComponent } from '../../includes/custom-tableloader/custom-tableloader.component';
import swal from 'sweetalert2';
import { DefaultLayoutComponent } from '../../layouts/default-layout/default-layout.component';
import TableFilterOptions from 'src/app/models/TableFiilterOptions';

@Component({
    selector: 'app-master-divisions',
    templateUrl: './divisions.component.html'
})
export class DivisionMasterComponent implements OnInit {
    Global = Global;
    divisionForm: FormGroup;
    paginationOptions: PaginationOptions;
    divisions: any[] = [];
    editActionId: any = null;

    constructor(
        private formBuilder: FormBuilder,
        private adminService: AdminService,
        private toastr: ToastrService,
        private spinner: NgxSpinnerService,
        private tableLoader: CustomTableLoaderComponent,
        private defaultLayout: DefaultLayoutComponent
    ) {
        this.divisionForm = formBuilder.group({
            name: [null, Validators.compose([Validators.required])],
        });

        this.paginationOptions = Global.resetPaginationOption();
    }

    async ngOnInit() {
        setTimeout(() => {
            this.defaultLayout.PageTitle = `<i class="icon-settings"></i>&nbsp;Divisions`
            this.defaultLayout.PageBreadcrumb = [
                { 'url': null, 'active': false, 'name': `Masters` },
                { 'url': null, 'active': true, 'name': `Divisions` },
            ]

            this.fetchDivisions()
        });
    }

    cancelEntry() {
        this.editActionId = null;
        Global.resetForm(this.divisionForm);
        Global.scrollToQuery('#division-submit-section');
    }

    getEdit(item: any) {
        this.cancelEntry();
        this.editActionId = item._id;
        this.divisionForm.patchValue({
            'name': item?.name ?? null,
        })
    }

    fetchDivisions(page: any = null, options: TableFilterOptions = Global.resetTableFilterOptions()) {
        if (page != null) {
            this.paginationOptions.page = page;
        }

        this.tableLoader.show();
        this.adminService.fetchDivisions({
            'pageno': this.paginationOptions.page,
            'searchkey': options.searchkey,
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.divisions = data.divisions?.docs ?? [];
                this.paginationOptions = {
                    hasNextPage: data.divisions.hasNextPage,
                    hasPrevPage: data.divisions.hasPrevPage,
                    limit: data.divisions.limit,
                    nextPage: data.divisions.nextPage,
                    page: data.divisions.page,
                    pagingCounter: data.divisions.pagingCounter,
                    prevPage: data.divisions.prevPage,
                    totalDocs: data.divisions.totalDocs,
                    totalPages: data.divisions.totalPages,
                };
            } else {
                this.toastr.error(res.message);

                this.divisions = [];
                this.paginationOptions = Global.resetPaginationOption();
            }

            this.tableLoader.hide();
        }, (err) => {
            this.divisions = [];
            this.tableLoader.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
            this.paginationOptions = Global.resetPaginationOption();
        });
    }

    addDivision(event: any) {
        this.divisionForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.divisionForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.createDivision({
                'name': this.divisionForm.value.name,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.cancelEntry();
                    this.fetchDivisions();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    editDivision(event: any) {
        this.divisionForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.divisionForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.updateDivision({
                'division_id': this.editActionId,
                'name': this.divisionForm.value.name,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.fetchDivisions();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    changeDivisionStatus(item: any) {
        this.spinner.show();
        this.adminService.changeDivisionStatus({
            'division_id': item._id,
            'status': (item.status == 'active') ? 'inactive' : 'active',
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.fetchDivisions();
                this.toastr.success(res.message);
            } else {
                this.toastr.error(res.message);
            }

            this.spinner.hide();
        }, (err) => {
            this.spinner.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
        });
    }

    deleteDivision(item: any) {
        swal.fire({
            title: 'Are you sure want to remove?',
            text: 'You will not be able to recover this data!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, keep it'
        }).then((result) => {
            if (result.value) {
                this.spinner.show();
                this.adminService.deleteDivision({
                    'division_id': item._id,
                }).subscribe(res => {
                    const data = res.data;
                    if (res.status == 'success') {
                        this.fetchDivisions();
                        this.toastr.success(res.message);
                    } else {
                        this.toastr.error(res.message);
                    }

                    this.spinner.hide();
                }, (err) => {
                    this.spinner.hide();
                    this.toastr.error(Global.getServerErrorMessage(err));
                });
            } else if (result.dismiss === swal.DismissReason.cancel) {
                swal.fire(
                    'Cancelled',
                    'Your data is safe :)',
                    'error'
                )
            }
        })
    }
}
