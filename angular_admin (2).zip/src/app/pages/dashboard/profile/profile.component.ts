import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as Global from 'src/app/global';
import { AdminService } from 'src/app/services/admin.service';
import { AuthService } from 'src/app/services/auth.service';
import { DefaultLayoutComponent } from '../../layouts/default-layout/default-layout.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html'
})
export class ProfileComponent implements OnInit {
  Global = Global;
  basicDetailsForm: FormGroup;
  passwordForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private adminService: AdminService,
    private authService: AuthService,
    private toastr: ToastrService,
    private spinner: NgxSpinnerService,
    private defaultLayout: DefaultLayoutComponent
  ) {
    this.basicDetailsForm = formBuilder.group({
      name: [null, Validators.compose([Validators.required])],
      email: [{ value: null, disabled: true }],
      mobile: [null, Validators.compose([Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)])],
    });

    this.passwordForm = formBuilder.group({
      current_password: [null, Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(20)])],
      new_password: [null, Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(20)])],
      new_password_confirmation: [null, Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(20)])],
    });
  }

  async ngOnInit() {
    setTimeout(() => {
      this.defaultLayout.PageTitle = `<i class="icon-user"></i>&nbsp;Profile`
      this.defaultLayout.PageBreadcrumb = [
        { 'url': null, 'active': false, 'name': `Profile` },
      ]
    });

    await this.fetchAccountDetails()
  }

  fetchAccountDetails() {
    return new Promise(resolve => {
      this.spinner.show();
      this.authService.getAdminAccountDetails().subscribe(res => {
        this.spinner.hide();
        const data = res.data;
        if (res.status == 'success') {
          this.basicDetailsForm.patchValue({
            'name': data.user?.name ?? null,
            'email': data.user?.email ?? null,
            'mobile': data.user?.mobile ?? null,
          })

          localStorage.setItem('admin-template-user', JSON.stringify(data.user));
          resolve(true);
        } else {
          this.toastr.error(res.message);
          resolve(false);
        }
      }, (err) => {
        this.toastr.error(Global.getServerErrorMessage(err));
        this.spinner.hide();
        resolve(false);
      })
    });
  }

  updateBasicDetails(event: any) {
    this.basicDetailsForm.markAllAsTouched();
    Global.scrollToQuery(".form-control.is-invalid");

    if (this.basicDetailsForm.valid) {
      event.target.classList.add('btn-loading');
      event.target.disabled = true;

      this.adminService.updateAdminProfile({
        'operation': "basicdetails",
        'name': this.basicDetailsForm.value.name,
        'email': this.basicDetailsForm.value.email,
        'mobile': this.basicDetailsForm.value.mobile,
      }).subscribe(res => {
        const data = res.data;
        if (res.status == 'success') {
          Global.resetForm(this.basicDetailsForm);
          this.toastr.success(res.message);
          this.fetchAccountDetails();
        } else if (res.status == 'val_error') {
          this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
        } else {
          this.toastr.error(res.message);
        }

        event.target.classList.remove('btn-loading');
        event.target.disabled = false;
      }, (err) => {
        event.target.classList.remove('btn-loading');
        event.target.disabled = false;
        this.toastr.error(Global.getServerErrorMessage(err));
      });
    }
  }

  updateAccountPassword(event: any) {
    this.passwordForm.markAllAsTouched();
    Global.scrollToQuery(".form-control.is-invalid");

    if (this.passwordForm.valid) {
      event.target.classList.add('btn-loading');
      event.target.disabled = true;

      this.adminService.updateAdminProfile({
        'operation': "password",
        'current_password': this.passwordForm.value.current_password,
        'new_password': this.passwordForm.value.new_password,
        'new_password_confirmation': this.passwordForm.value.new_password_confirmation,
      }).subscribe(res => {
        const data = res.data;
        if (res.status == 'success') {
          Global.resetForm(this.passwordForm);
          this.toastr.success(res.message);
        } else if (res.status == 'val_error') {
          this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
        } else {
          this.toastr.error(res.message);
        }

        event.target.classList.remove('btn-loading');
        event.target.disabled = false;
      }, (err) => {
        event.target.classList.remove('btn-loading');
        event.target.disabled = false;
        this.toastr.error(Global.getServerErrorMessage(err));
      });
    }
  }
}
