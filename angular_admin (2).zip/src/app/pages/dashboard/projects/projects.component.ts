import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as Global from 'src/app/global';
import PaginationOptions from 'src/app/models/PaginationOptions';
import { AdminService } from 'src/app/services/admin.service';
import { CustomTableLoaderComponent } from '../../includes/custom-tableloader/custom-tableloader.component';
import swal from 'sweetalert2';
import { DefaultLayoutComponent } from '../../layouts/default-layout/default-layout.component';
import TableFilterOptions from 'src/app/models/TableFiilterOptions';

@Component({
    selector: 'app-projects',
    templateUrl: './projects.component.html'
})
export class ProjectsComponent implements OnInit {
    Global = Global;
    projectForm: FormGroup;
    paginationOptions: PaginationOptions;
    projects: any[] = [];
    editActionId: any = null;

    constructor(
        private formBuilder: FormBuilder,
        private adminService: AdminService,
        private toastr: ToastrService,
        private spinner: NgxSpinnerService,
        private tableLoader: CustomTableLoaderComponent,
        private defaultLayout: DefaultLayoutComponent
    ) {
        this.projectForm = formBuilder.group({
            name: [null, Validators.compose([Validators.required])],
            location: [null, Validators.compose([Validators.required])],
            image: [null, Validators.compose([Validators.required])],
            image_source: [null, Validators.compose([])],
        });

        this.paginationOptions = Global.resetPaginationOption();
    }

    async ngOnInit() {
        setTimeout(() => {
            this.defaultLayout.PageTitle = `<i class="cil-apps"></i>&nbsp;Projects`
            this.defaultLayout.PageBreadcrumb = [
                { 'url': null, 'active': true, 'name': `Projects` },
            ]

            this.fetchProjects()
        });
    }

    cancelEntry() {
        this.projectForm.controls['image'].setValidators([Validators.required]);
        this.projectForm.controls['image'].updateValueAndValidity();

        this.editActionId = null;
        Global.resetForm(this.projectForm);
        Global.scrollToQuery('#project-submit-section');
    }

    getEdit(item: any) {
        this.cancelEntry();
        this.editActionId = item._id;
        this.projectForm.patchValue({
            'name': item?.name ?? null,
            'location': item?.location ?? null,
        })

        this.projectForm.controls['image'].clearValidators();
        this.projectForm.controls['image'].updateValueAndValidity();
    }

    fetchProjects(page: any = null, options: TableFilterOptions = Global.resetTableFilterOptions()) {
        if (page != null) {
            this.paginationOptions.page = page;
        }

        this.tableLoader.show();
        this.adminService.fetchProjects({
            'pageno': this.paginationOptions.page,
            'searchkey': options.searchkey,
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.projects = data.projects?.docs ?? [];
                this.paginationOptions = {
                    hasNextPage: data.projects.hasNextPage,
                    hasPrevPage: data.projects.hasPrevPage,
                    limit: data.projects.limit,
                    nextPage: data.projects.nextPage,
                    page: data.projects.page,
                    pagingCounter: data.projects.pagingCounter,
                    prevPage: data.projects.prevPage,
                    totalDocs: data.projects.totalDocs,
                    totalPages: data.projects.totalPages,
                };
            } else {
                this.toastr.error(res.message);

                this.projects = [];
                this.paginationOptions = Global.resetPaginationOption();
            }

            this.tableLoader.hide();
        }, (err) => {
            this.projects = [];
            this.tableLoader.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
            this.paginationOptions = Global.resetPaginationOption();
        });
    }

    addProject(event: any) {
        this.projectForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.projectForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.createProject({
                'name': this.projectForm.value.name ?? "",
                'location': this.projectForm.value.location ?? "",
                'image': this.projectForm.value.image_source ?? "",
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.cancelEntry();
                    this.fetchProjects();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    editProject(event: any) {
        this.projectForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.projectForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.updateProject({
                'project_id': this.editActionId,
                'name': this.projectForm.value.name ?? "",
                'location': this.projectForm.value.location ?? "",
                'image': this.projectForm.value.image_source ?? "",
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.fetchProjects();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    changeProjectStatus(item: any) {
        this.spinner.show();
        this.adminService.changeProjectStatus({
            'project_id': item._id,
            'status': (item.status == 'active') ? 'inactive' : 'active',
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.fetchProjects();
                this.toastr.success(res.message);
            } else {
                this.toastr.error(res.message);
            }

            this.spinner.hide();
        }, (err) => {
            this.spinner.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
        });
    }

    deleteProject(item: any) {
        swal.fire({
            title: 'Are you sure want to remove?',
            text: 'You will not be able to recover this data!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, keep it'
        }).then((result) => {
            if (result.value) {
                this.spinner.show();
                this.adminService.deleteProject({
                    'project_id': item._id,
                }).subscribe(res => {
                    const data = res.data;
                    if (res.status == 'success') {
                        this.fetchProjects();
                        this.toastr.success(res.message);
                    } else {
                        this.toastr.error(res.message);
                    }

                    this.spinner.hide();
                }, (err) => {
                    this.spinner.hide();
                    this.toastr.error(Global.getServerErrorMessage(err));
                });
            } else if (result.dismiss === swal.DismissReason.cancel) {
                swal.fire(
                    'Cancelled',
                    'Your data is safe :)',
                    'error'
                )
            }
        })
    }
}
