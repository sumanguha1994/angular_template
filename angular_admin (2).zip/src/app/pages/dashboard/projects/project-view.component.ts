import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as Global from 'src/app/global';
import PaginationOptions from 'src/app/models/PaginationOptions';
import { AdminService } from 'src/app/services/admin.service';
import { CustomTableLoaderComponent } from '../../includes/custom-tableloader/custom-tableloader.component';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap/modal';
import * as moment from 'moment';
import swal from 'sweetalert2';
import { DefaultLayoutComponent } from '../../layouts/default-layout/default-layout.component';

@Component({
    selector: 'app-project-view',
    templateUrl: './project-view.component.html'
})
export class ProjectViewComponent implements OnInit {
    Global = Global;

    projectDetails: any = null
    project_id: any = null

    projectTasks: any[] = [];
    projectChannels: any[] = [];
    projectChannelUsers: any[] = [];
    projectChannelDetails: any = null;
    projectTasksPaginationOptions: PaginationOptions;
    projectChannelsPaginationOptions: PaginationOptions;
    projectChannelUsersPaginationOptions: PaginationOptions;
    projectTaskForm: FormGroup;
    projectChannelUserForm: FormGroup;
    projectTaskEditActionId: any = null;
    projectTaskPriorityMaster: any[] = [];
    projectChannelUserAssigneMaster: any[] = [];
    divisionMaster: any[] = [];

    @ViewChild('projectTaskModal') public projectTaskModal: ModalDirective;
    @ViewChild('projectChannelUsersModal') public projectChannelUsersModal: ModalDirective;

    constructor(
        private formBuilder: FormBuilder,
        private adminService: AdminService,
        private toastr: ToastrService,
        private spinner: NgxSpinnerService,
        private tableLoader: CustomTableLoaderComponent,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private defaultLayout: DefaultLayoutComponent
    ) {
        this.projectTaskForm = formBuilder.group({
            division_id: [null, Validators.compose([Validators.required])],
            end_date: [null, Validators.compose([Validators.required])],
            priority: [null, Validators.compose([Validators.required])],
            description: [null, Validators.compose([Validators.required])],
        });

        this.projectChannelUserForm = formBuilder.group({
            project_id: [null, Validators.compose([])],
            division_id: [null, Validators.compose([])],
            user_id: [null, Validators.compose([Validators.required])],
        });

        this.projectTaskPriorityMaster = [
            { 'value': "low", 'label': "Low" },
            { 'value': "moderate", 'label': "Moderate" },
            { 'value': "high", 'label': "High" },
        ];

        this.projectTasksPaginationOptions = Global.resetPaginationOption();
        this.projectChannelsPaginationOptions = Global.resetPaginationOption();
        this.projectChannelUsersPaginationOptions = Global.resetPaginationOption();
    }

    async ngOnInit() {
        setTimeout(() => {
            this.defaultLayout.PageTitle = `<i class="cil-apps"></i>&nbsp;Projects`
            this.defaultLayout.PageBreadcrumb = [
                { 'url': '/projects', 'active': false, 'name': `Projects` },
                { 'url': null, 'active': true, 'name': `Details` },
            ]
        });

        this.project_id = this.activatedRoute.snapshot.paramMap.get('project_id');
        await this.fetchProjectDetails();
        this.fetchProjectChannels()
        this.fetchProjectTasks()
    }

    fetchProjectDetails() {
        return new Promise((resolve, reject) => {
            this.spinner.show();
            this.adminService.fetchProjectDetails({
                'project_id': this.project_id,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.projectDetails = data.project;
                    this.divisionMaster = data?.master?.divisions ?? []
                } else if (res.status == 'val_error') {
                    // this.router.navigate(['/projects']);
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    // this.router.navigate(['/projects']);
                    this.toastr.error(res.message);
                }

                this.spinner.hide();
                resolve(true);
            }, (err) => {
                // this.router.navigate(['/projects']);
                this.toastr.error(Global.getServerErrorMessage(err));
                this.spinner.hide();
                resolve(true);
            });
        })
    }

    /**
     * -------------------------
     * PROJECT CHANNEL FUNCTIONS
     * -------------------------
     * -------------------------
     */

    fetchProjectChannels(page: any = null) {
        return new Promise((resolve, reject) => {
            if (page != null) {
                this.projectChannelsPaginationOptions.page = page;
            }

            this.tableLoader.show({ id: "projectchannels-list" });
            this.adminService.fetchProjectChannels({
                'project_id': this.project_id,
                'pageno': this.projectChannelsPaginationOptions.page,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.projectChannels = data.channels?.docs ?? [];
                    this.projectChannelsPaginationOptions = {
                        hasNextPage: data.channels.hasNextPage,
                        hasPrevPage: data.channels.hasPrevPage,
                        limit: data.channels.limit,
                        nextPage: data.channels.nextPage,
                        page: data.channels.page,
                        pagingCounter: data.channels.pagingCounter,
                        prevPage: data.channels.prevPage,
                        totalDocs: data.channels.totalDocs,
                        totalPages: data.channels.totalPages,
                    };
                } else {
                    this.toastr.error(res.message);

                    this.projectChannels = [];
                    this.projectChannelsPaginationOptions = Global.resetPaginationOption();
                }

                this.tableLoader.hide({ id: "projectchannels-list" });
                resolve(true);
            }, (err) => {
                this.projectTasks = [];
                this.tableLoader.hide({ id: "projectchannels-list" });
                this.toastr.error(Global.getServerErrorMessage(err));
                this.projectChannelsPaginationOptions = Global.resetPaginationOption();
                resolve(true);
            });
        })
    }

    async initChannelAssignUser(item: any) {
        this.cancelChannelAssignUser();
        this.projectChannelDetails = item;
        await this.fetchUserAssignesForProjectChannel();
        this.projectChannelUsersModal.show();
        await this.fetchProjectChannelUsers();

        // this.projectChannelUserForm.patchValue({
        //     project_id: this.projectDetails?._id,
        //     division_id: this.projectChannelDetails?.division_id,
        // })
    }

    async cancelChannelAssignUser() {
        Global.resetForm(this.projectChannelUserForm);
        this.projectChannelUsersModal.hide();
        this.projectChannelDetails = null;
        this.projectChannelUsers = [];

        await this.fetchProjectChannels();
    }

    fetchUserAssignesForProjectChannel() {
        return new Promise((resolve, reject) => {
            this.spinner.show();
            this.projectChannelUserAssigneMaster = [];
            this.adminService.fetchUserAssignesForProjectChannel({
                division_id: this.projectChannelDetails?.division_id,
                project_id: this.projectDetails?._id,
            }).subscribe(res => {
                const data = res.data;
                data.users.forEach((user: any) => {
                    user.description = user.name + ' ( ' + user.role.toUpperCase() + ' )'
                });
                this.projectChannelUserAssigneMaster = data.users;
                this.spinner.hide();
                resolve(true);
            }, (err) => {
                this.spinner.hide();
                this.toastr.error(Global.getServerErrorMessage(err));
                resolve(true);
            });
        })
    }

    fetchProjectChannelUsers(page: any = null) {
        return new Promise((resolve, reject) => {
            if (page != null) {
                this.projectChannelUsersPaginationOptions.page = page;
            }

            this.tableLoader.show({ id: "projectchannelusers-list" });
            this.adminService.fetchProjectChannelUsers({
                'project_id': this.projectDetails?._id,
                'division_id': this.projectChannelDetails?.division_id,
                'pageno': this.projectChannelUsersPaginationOptions.page,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.projectChannelUsers = data.users?.docs ?? [];
                    this.projectChannelUsersPaginationOptions = {
                        hasNextPage: data.users.hasNextPage,
                        hasPrevPage: data.users.hasPrevPage,
                        limit: data.users.limit,
                        nextPage: data.users.nextPage,
                        page: data.users.page,
                        pagingCounter: data.users.pagingCounter,
                        prevPage: data.users.prevPage,
                        totalDocs: data.users.totalDocs,
                        totalPages: data.users.totalPages,
                    };
                } else {
                    this.toastr.error(res.message);

                    this.projectChannelUsers = [];
                    this.projectChannelUsersPaginationOptions = Global.resetPaginationOption();
                }

                this.tableLoader.hide({ id: "projectchannelusers-list" });
                resolve(true);
            }, (err) => {
                this.projectChannelUsers = [];
                this.tableLoader.hide({ id: "projectchannelusers-list" });
                this.toastr.error(Global.getServerErrorMessage(err));
                this.projectChannelUsersPaginationOptions = Global.resetPaginationOption();
                resolve(true);
            });
        })
    }

    assignUserToProjectChannel(event: any) {
        this.projectChannelUserForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.projectChannelUserForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.assignUserToProjectChannel({
                'project_id': this.projectDetails?._id,
                'division_id': this.projectChannelDetails?.division_id,
                'user_id': this.projectChannelUserForm.value.user_id,
            }).subscribe(async res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);

                    Global.resetForm(this.projectChannelUserForm);
                    this.projectChannelUserForm.patchValue({
                        project_id: this.projectDetails?._id,
                        division_id: this.projectChannelDetails.division_id,
                    })

                    await this.fetchUserAssignesForProjectChannel()
                    await this.fetchProjectChannelUsers();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    removeUserFromProjectChannel(item: any) {
        console.log(item)

        swal.fire({
            title: 'Are you sure want to remove?',
            text: 'You will not be able to recover this data!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, remove it!',
            cancelButtonText: 'No, keep it'
        }).then((result) => {
            if (result.value) {
                this.spinner.show();
                this.adminService.removeUserFromProjectChannel({
                    'project_id': this.projectDetails?._id,
                    'division_id': this.projectChannelDetails?.division_id,
                    'user_id': item._id,
                }).subscribe(async res => {
                    const data = res.data;
                    if (res.status == 'success') {
                        await this.fetchUserAssignesForProjectChannel()
                        this.fetchProjectChannelUsers();
                        this.toastr.success(res.message);
                    } else {
                        this.toastr.error(res.message);
                    }

                    this.spinner.hide();
                }, (err) => {
                    this.spinner.hide();
                    this.toastr.error(Global.getServerErrorMessage(err));
                });
            } else if (result.dismiss === swal.DismissReason.cancel) {
                swal.fire(
                    'Cancelled',
                    'Your data is safe :)',
                    'error'
                )
            }
        })
    }

    /**
     * -------------------------
     * PROJECT TASK FUNCTIONS
     * -------------------------
     * -------------------------
     */

    fetchProjectTasks(page: any = null) {
        return new Promise((resolve, reject) => {
            if (page != null) {
                this.projectTasksPaginationOptions.page = page;
            }

            this.tableLoader.show({ id: "projecttasks-list" });
            this.adminService.fetchProjectTasks({
                'project_id': this.project_id,
                'pageno': this.projectTasksPaginationOptions.page,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.projectTasks = data.project_tasks?.docs ?? [];
                    this.projectTasksPaginationOptions = {
                        hasNextPage: data.project_tasks.hasNextPage,
                        hasPrevPage: data.project_tasks.hasPrevPage,
                        limit: data.project_tasks.limit,
                        nextPage: data.project_tasks.nextPage,
                        page: data.project_tasks.page,
                        pagingCounter: data.project_tasks.pagingCounter,
                        prevPage: data.project_tasks.prevPage,
                        totalDocs: data.project_tasks.totalDocs,
                        totalPages: data.project_tasks.totalPages,
                    };
                } else {
                    this.toastr.error(res.message);

                    this.projectTasks = [];
                    this.projectTasksPaginationOptions = Global.resetPaginationOption();
                }

                this.tableLoader.hide({ id: "projecttasks-list" });
                resolve(true);
            }, (err) => {
                this.projectTasks = [];
                this.tableLoader.hide({ id: "projecttasks-list" });
                this.toastr.error(Global.getServerErrorMessage(err));
                this.projectTasksPaginationOptions = Global.resetPaginationOption();
                resolve(true);
            });
        })
    }

    initProjectTaskCreate() {
        this.cancelProjectTaskEntry();
        this.projectTaskModal.show();
    }

    addProjectTask(event: any) {
        this.projectTaskForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.projectTaskForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.createProjectTask({
                'project_id': this.project_id,
                'division_id': this.projectTaskForm.value.division_id,
                'end_date': this.projectTaskForm.value.end_date ? moment(this.projectTaskForm.value.end_date).format('YYYY-MM-DD') : "",
                'priority': this.projectTaskForm.value.priority ?? "",
                'description': this.projectTaskForm.value.description ?? "",
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.cancelProjectTaskEntry();
                    this.fetchProjectTasks();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    cancelProjectTaskEntry() {
        Global.resetForm(this.projectTaskForm);
        this.projectTaskEditActionId = null;
        this.projectTaskModal.hide();

        this.projectTaskForm.controls['division_id'].enable();
        this.projectTaskForm.controls['division_id'].clearValidators();
        this.projectTaskForm.controls['division_id'].updateValueAndValidity();
    }

    changeProjectTaskStatus(item: any) {
        this.spinner.show();
        this.adminService.changeProjectTaskStatus({
            'task_id': item._id,
            'status': (item.status == 'active') ? 'inactive' : 'active',
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.fetchProjectTasks();
                this.toastr.success(res.message);
            } else {
                this.toastr.error(res.message);
            }

            this.spinner.hide();
        }, (err) => {
            this.spinner.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
        });
    }

    getProjectTaskEdit(item: any) {
        this.cancelProjectTaskEntry();

        this.projectTaskEditActionId = item._id;
        this.projectTaskForm.patchValue({
            'division_id': item.division_id ?? null,
            'end_date': item.end_date ? moment(item.end_date).toDate() : null,
            'priority': item.priority ?? null,
            'description': item.description ?? null,
        });

        this.projectTaskForm.controls['division_id'].disable();
        this.projectTaskForm.controls['division_id'].setValidators([Validators.required]);
        this.projectTaskForm.controls['division_id'].updateValueAndValidity();

        this.projectTaskModal.show();
    }

    deleteProjectTask(item: any) {
        swal.fire({
            title: 'Are you sure want to remove?',
            text: 'You will not be able to recover this data!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, keep it'
        }).then((result) => {
            if (result.value) {
                this.spinner.show();
                this.adminService.deleteProjectTask({
                    'task_id': item._id,
                }).subscribe(res => {
                    const data = res.data;
                    if (res.status == 'success') {
                        this.fetchProjectTasks();
                        this.toastr.success(res.message);
                    } else {
                        this.toastr.error(res.message);
                    }

                    this.spinner.hide();
                }, (err) => {
                    this.spinner.hide();
                    this.toastr.error(Global.getServerErrorMessage(err));
                });
            } else if (result.dismiss === swal.DismissReason.cancel) {
                swal.fire(
                    'Cancelled',
                    'Your data is safe :)',
                    'error'
                )
            }
        })
    }

    editProjectTask(event: any) {
        this.projectTaskForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.projectTaskForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.updateProjectTask({
                'task_id': this.projectTaskEditActionId,
                'end_date': this.projectTaskForm.value.end_date ? moment(this.projectTaskForm.value.end_date).format('YYYY-MM-DD') : "",
                'priority': this.projectTaskForm.value.priority ?? "",
                'description': this.projectTaskForm.value.description ?? "",
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.fetchProjectTasks();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }
}
