import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as Global from 'src/app/global';
import PaginationOptions from 'src/app/models/PaginationOptions';
import { AdminService } from 'src/app/services/admin.service';
import { CustomTableLoaderComponent } from '../../includes/custom-tableloader/custom-tableloader.component';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalDirective } from 'ngx-bootstrap/modal';
import * as moment from 'moment';
import swal from 'sweetalert2';
import { DefaultLayoutComponent } from '../../layouts/default-layout/default-layout.component';

@Component({
    selector: 'app-project-task-view',
    templateUrl: './project-task-view.component.html'
})
export class ProjectTaskViewComponent implements OnInit {
    Global = Global;

    taskDetails: any = null
    task_id: any = null
    userAssigneeMaster: any[] = [];
    projectTaskUsers: any[] = [];
    projectUsersPaginationOptions: PaginationOptions;
    projectTaskUserForm: FormGroup;
    projectTaskUserStatusForm: FormGroup;
    projectTaskUserStatusMaster: any[] = [];

    @ViewChild('projectTaskUserModal') public projectTaskUserModal: ModalDirective;
    @ViewChild('projectTaskUserStatusModal') public projectTaskUserStatusModal: ModalDirective;

    constructor(
        private formBuilder: FormBuilder,
        private adminService: AdminService,
        private toastr: ToastrService,
        private spinner: NgxSpinnerService,
        private tableLoader: CustomTableLoaderComponent,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private defaultLayout: DefaultLayoutComponent
    ) {
        this.projectTaskUserForm = formBuilder.group({
            user_id: [null, Validators.compose([Validators.required])],
        });

        this.projectTaskUserStatusForm = formBuilder.group({
            assigne_id: [null, Validators.compose([Validators.required])],
            status: [null, Validators.compose([Validators.required])],
        });

        this.projectUsersPaginationOptions = Global.resetPaginationOption();

        this.projectTaskUserStatusMaster = [
            { 'value': "pending", 'label': "Pending" },
            { 'value': "inprogress", 'label': "Inprogress" },
            { 'value': "completed", 'label': "Completed" },
        ];
    }

    async ngOnInit() {
        setTimeout(() => {
            this.defaultLayout.PageTitle = `<i class="cil-apps"></i>&nbsp;Projects`
            this.defaultLayout.PageBreadcrumb = [
                { 'url': '/projects', 'active': false, 'name': `Projects` },
            ]
        });

        this.task_id = this.activatedRoute.snapshot.paramMap.get('task_id');
        await this.fetchProjectTaskDetails();
        this.fetchProjectTaskUsers()

        this.defaultLayout.PageBreadcrumb.push(
            { 'url': `/projects/${this.taskDetails?.project?._id}/view`, 'active': false, 'name': this.taskDetails?.project?.name },
            { 'url': null, 'active': false, 'name': `Task Details` },
        )
    }

    fetchProjectTaskDetails() {
        return new Promise((resolve, reject) => {
            this.spinner.show();
            this.adminService.fetchProjectTaskDetails({
                'task_id': this.task_id,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.taskDetails = data.project_task;
                } else if (res.status == 'val_error') {
                    // this.router.navigate(['/projects']);
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    // this.router.navigate(['/projects']);
                    this.toastr.error(res.message);
                }

                this.spinner.hide();
                resolve(true);
            }, (err) => {
                // this.router.navigate(['/projects']);
                this.toastr.error(Global.getServerErrorMessage(err));
                this.spinner.hide();
                resolve(true);
            });
        })
    }


    fetchProjectTaskUsers(page: any = null) {
        if (page != null) {
            this.projectUsersPaginationOptions.page = page;
        }

        this.tableLoader.show();
        this.adminService.fetchProjectTaskUsers({
            'task_id': this.task_id,
            'pageno': this.projectUsersPaginationOptions.page,
        }).subscribe(res => {
            const data = res.data;
            if (res.status == 'success') {
                this.projectTaskUsers = data.project_task_users?.docs ?? [];
                this.projectUsersPaginationOptions = {
                    hasNextPage: data.project_task_users.hasNextPage,
                    hasPrevPage: data.project_task_users.hasPrevPage,
                    limit: data.project_task_users.limit,
                    nextPage: data.project_task_users.nextPage,
                    page: data.project_task_users.page,
                    pagingCounter: data.project_task_users.pagingCounter,
                    prevPage: data.project_task_users.prevPage,
                    totalDocs: data.project_task_users.totalDocs,
                    totalPages: data.project_task_users.totalPages,
                };
            } else {
                this.toastr.error(res.message);

                this.projectTaskUsers = [];
                this.projectUsersPaginationOptions = Global.resetPaginationOption();
            }

            this.tableLoader.hide();
        }, (err) => {
            this.projectTaskUsers = [];
            this.tableLoader.hide();
            this.toastr.error(Global.getServerErrorMessage(err));
            this.projectUsersPaginationOptions = Global.resetPaginationOption();
        });
    }

    async initProjectTaskUserAssign() {
        this.cancelProjectTaskUserEntry();
        await this.fetchUserAssignesForTask();
        this.projectTaskUserModal.show();
    }

    removeUserFromTask(item: any) {
        swal.fire({
            title: 'Are you sure want to remove?',
            text: 'You will not be able to recover this data!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, remove it!',
            cancelButtonText: 'No, keep it'
        }).then((result) => {
            if (result.value) {
                this.spinner.show();
                this.adminService.removeUserFromTask({
                    'task_id': item.task_id,
                    'user_id': item.user_id,
                }).subscribe(res => {
                    const data = res.data;
                    if (res.status == 'success') {
                        this.fetchProjectTaskUsers();
                        this.toastr.success(res.message);
                    } else {
                        this.toastr.error(res.message);
                    }

                    this.spinner.hide();
                }, (err) => {
                    this.spinner.hide();
                    this.toastr.error(Global.getServerErrorMessage(err));
                });
            } else if (result.dismiss === swal.DismissReason.cancel) {
                swal.fire(
                    'Cancelled',
                    'Your data is safe :)',
                    'error'
                )
            }
        })
    }

    fetchUserAssignesForTask() {
        return new Promise((resolve, reject) => {
            this.userAssigneeMaster = [];
            this.spinner.show();
            this.adminService.fetchUserAssignesForTask({
                'task_id': this.task_id,
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    data.users.forEach((user: any) => {
                        user.description = user.name + ' ( ' + user.role.toUpperCase() + ' )'
                    });
                    this.userAssigneeMaster = data.users;
                } else {
                    this.toastr.error(res.message);
                }

                this.spinner.hide();
                resolve(true);
            }, (err) => {
                this.spinner.hide();
                this.toastr.error(Global.getServerErrorMessage(err));
                resolve(true);
            });
        })
    }

    cancelProjectTaskUserEntry() {
        Global.resetForm(this.projectTaskUserForm);
        this.projectTaskUserModal.hide();
    }

    assignUserToTask(event: any) {
        this.projectTaskUserForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.projectTaskUserForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.assignUserToTask({
                'task_id': this.task_id,
                'user_id': this.projectTaskUserForm.value.user_id ?? "",
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.cancelProjectTaskUserEntry();
                    this.fetchProjectTaskUsers();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }

    initUserTaskStatusEdit(item: any) {
        this.projectTaskUserStatusForm.patchValue({
            'assigne_id': item._id,
            'status': item.status,
        })

        this.projectTaskUserStatusModal.show();
    }

    cancelUserTaskStatusEdit() {
        Global.resetForm(this.projectTaskUserStatusForm);
        this.projectTaskUserStatusModal.hide();
    }

    updateUserTaskStatus(event: any) {
        this.projectTaskUserStatusForm.markAllAsTouched();
        Global.scrollToQuery(".form-control.is-invalid");

        if (this.projectTaskUserStatusForm.valid) {
            event.target.classList.add('btn-loading');
            event.target.disabled = true;

            this.adminService.updateUserTaskStatus({
                'assigne_id': this.projectTaskUserStatusForm.value.assigne_id ?? "",
                'status': this.projectTaskUserStatusForm.value.status ?? "",
            }).subscribe(res => {
                const data = res.data;
                if (res.status == 'success') {
                    this.toastr.success(res.message);
                    this.cancelUserTaskStatusEdit();
                    this.fetchProjectTaskUsers();
                } else if (res.status == 'val_error') {
                    this.toastr.error(Global.getValidationMessage(data?.errors ?? []));
                } else {
                    this.toastr.error(res.message);
                }

                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
            }, (err) => {
                event.target.classList.remove('btn-loading');
                event.target.disabled = false;
                this.toastr.error(Global.getServerErrorMessage(err));
            });
        }
    }
}
