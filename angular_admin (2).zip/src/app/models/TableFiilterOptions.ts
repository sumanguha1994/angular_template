export default class TableFilterOptions {
  searchkey: string = "";  
}
